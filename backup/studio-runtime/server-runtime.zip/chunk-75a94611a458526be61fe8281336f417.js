import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var e="wanakaAuthoringInternal",a="data-wanaka-authoring-id",n="wanaka-html-ui-authoring-overlay",o=new WeakSet;function r(t){o.add(t)}function s(t){return o.has(t)}export{e as a,a as b,n as c,r as d,s as e};
