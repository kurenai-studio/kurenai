import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
function n(e){return Object.keys(e)}export{n as a};
