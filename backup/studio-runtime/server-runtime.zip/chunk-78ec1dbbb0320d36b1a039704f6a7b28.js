import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as e}from"./chunk-af4a0f353769a78e174f04db2f366209.js";import{c as a}from"./chunk-455e93148f25cfd617316d4873aa2468.js";var f=e("purple-hair","e6769116-ea15-100d-397e-47fba0214fbd",a("e6769116-ea15-100d-397e-47fba0214fbd"),1.971177);export{f as a};
