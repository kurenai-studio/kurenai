import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var i;function a(e){i=e}var o=new WeakMap;function n(e,t){return o.set(e,t),()=>o.delete(e)}function r(e){let t=o.get(e);if(!t)throw new Error("Navigation debug feed is unavailable.");return t()}export{a,n as b,r as c};
