import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as e}from"./chunk-af4a0f353769a78e174f04db2f366209.js";import{c as a}from"./chunk-455e93148f25cfd617316d4873aa2468.js";var f=e("gold-twin-tails","2b564388-e598-af92-8bea-597a0de30787",a("2b564388-e598-af92-8bea-597a0de30787"),1.936809);export{f as a};
