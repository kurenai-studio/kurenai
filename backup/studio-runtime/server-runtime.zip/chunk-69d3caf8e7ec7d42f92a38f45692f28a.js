import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var n=new WeakMap;function a(e,i,o){let t=n.get(e);t||(t=new Map,n.set(e,t)),t.set(i,o)}function p(e,i){return n.get(e)?.get(i)}export{a,p as b};
