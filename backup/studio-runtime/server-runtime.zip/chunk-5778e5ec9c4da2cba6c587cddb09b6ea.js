import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var n=new WeakMap;function a(e,r){return n.set(e,r),()=>{n.get(e)===r&&n.delete(e)}}function t(e){return n.get(e)}export{a,t as b};
