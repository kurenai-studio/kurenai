import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import"./chunk-266dd0f2f8e0093a40d25f28f00505f3.js";import{Hd as C,bc as w,ld as B,nd as j,od as z,pd as W}from"./chunk-e2afe90afb807d84f9ee8f5730ad85f1.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";var L=class{parse(S){let o="",u=0,v=0,A=0,n=new j,b=new C,d=new j,M=new B,y=[];function N(e){let m=0,x=0,l=0,f=e.geometry,t=new z,i=f.getAttribute("position"),a=f.getAttribute("normal"),p=f.getAttribute("uv"),V=f.getIndex();if(o+="o "+e.name+`
`,e.material&&e.material.name&&(o+="usemtl "+e.material.name+`
`),i!==void 0)for(let r=0,s=i.count;r<s;r++,m++)n.fromBufferAttribute(i,r),n.applyMatrix4(e.matrixWorld),o+="v "+n.x+" "+n.y+" "+n.z+`
`;if(p!==void 0)for(let r=0,s=p.count;r<s;r++,l++)M.fromBufferAttribute(p,r),o+="vt "+M.x+" "+M.y+`
`;if(a!==void 0){t.getNormalMatrix(e.matrixWorld);for(let r=0,s=a.count;r<s;r++,x++)d.fromBufferAttribute(a,r),d.applyMatrix3(t).normalize(),o+="vn "+d.x+" "+d.y+" "+d.z+`
`}if(V!==null)for(let r=0,s=V.count;r<s;r+=3){for(let c=0;c<3;c++){let g=V.getX(r+c)+1;y[c]=u+g+(a||p?"/"+(p?v+g:"")+(a?"/"+(A+g):""):"")}o+="f "+y.join(" ")+`
`}else for(let r=0,s=i.count;r<s;r+=3){for(let c=0;c<3;c++){let g=r+c+1;y[c]=u+g+(a||p?"/"+(p?v+g:"")+(a?"/"+(A+g):""):"")}o+="f "+y.join(" ")+`
`}u+=m,v+=l,A+=x}function k(e){let m=0,x=e.geometry,l=e.type,f=x.getAttribute("position");if(o+="o "+e.name+`
`,f!==void 0)for(let t=0,i=f.count;t<i;t++,m++)n.fromBufferAttribute(f,t),n.applyMatrix4(e.matrixWorld),o+="v "+n.x+" "+n.y+" "+n.z+`
`;if(l==="Line"){o+="l ";for(let t=1,i=f.count;t<=i;t++)o+=u+t+" ";o+=`
`}if(l==="LineSegments")for(let t=1,i=t+1,a=f.count;t<a;t+=2,i=t+1)o+="l "+(u+t)+" "+(u+i)+`
`;u+=m}function P(e){let m=0,x=e.geometry,l=x.getAttribute("position"),f=x.getAttribute("color");if(o+="o "+e.name+`
`,l!==void 0){for(let t=0,i=l.count;t<i;t++,m++)n.fromBufferAttribute(l,t),n.applyMatrix4(e.matrixWorld),o+="v "+n.x+" "+n.y+" "+n.z,f!==void 0&&(b.fromBufferAttribute(f,t),W.workingToColorSpace(b,w),o+=" "+b.r+" "+b.g+" "+b.b),o+=`
`;o+="p ";for(let t=1,i=l.count;t<=i;t++)o+=u+t+" ";o+=`
`}u+=m}return S.traverse(function(e){e.isMesh===!0&&N(e),e.isLine===!0&&k(e),e.isPoints===!0&&P(e)}),o}};export{L as OBJExporter};
