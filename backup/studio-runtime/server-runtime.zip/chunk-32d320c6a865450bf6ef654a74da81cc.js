import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var l=null;function r(e){l=e}function o(e){return l?.(e)??!1}export{r as a,o as b};
