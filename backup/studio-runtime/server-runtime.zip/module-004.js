import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as o}from"./chunk-109c1ba96459c7035febb4e88707d616.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";export{o as WANAKA_HOST_PROTOCOL};
