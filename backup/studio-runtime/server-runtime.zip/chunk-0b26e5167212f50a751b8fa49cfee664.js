import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
function i(o,t){return o.getWorldPosition?o.getWorldPosition(t):t.set(o.position.x,o.position.y,o.position.z)}export{i as a};
