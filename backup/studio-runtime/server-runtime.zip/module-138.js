import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as o}from"./chunk-dd622828f559e01ac5bb3b3e1565fd44.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";export{o as MeshoptDecoder};
