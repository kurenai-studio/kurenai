import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{Tc as o,Xk as s,ae as r,ej as e,p as n}from"./chunk-fda4dbdf307d7a1877f6bc2d6aa2f8a6.js";var d=n(([t=o(1),u=o(.5),c=s()])=>{let m=c.sub(.5),i=r(m).mul(2),l=t,p=t.sub(u.mul(t));return e(l,p,i)});export{d as a};
