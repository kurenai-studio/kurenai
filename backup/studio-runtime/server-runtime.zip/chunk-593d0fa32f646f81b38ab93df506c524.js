import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as e}from"./chunk-af4a0f353769a78e174f04db2f366209.js";import{c as a}from"./chunk-455e93148f25cfd617316d4873aa2468.js";var c=e("cat-ear-glasses","1919164a-4b82-f7ca-ae6c-22445f18dc0a",a("1919164a-4b82-f7ca-ae6c-22445f18dc0a"),1.986016);export{c as a};
