import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as o}from"./chunk-9c0664c8ec9308dfdd66c89b814410e9.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";export{o as MeshoptSimplifier};
