import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
function a(t,r,n,o=""){let e=r(t,o);e.nodePath&&n(e);for(let i of t.children){let c=a(i,r,n,e.nodePath);e.add(c)}return e}function l(t,r,n){let o=new DOMParser().parseFromString(t,"application/xml").documentElement;return a(o,r,n)}export{a,l as b};
