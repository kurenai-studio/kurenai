import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as e}from"./chunk-af4a0f353769a78e174f04db2f366209.js";import{c as a}from"./chunk-455e93148f25cfd617316d4873aa2468.js";var f=e("black-headscarf","61654c1e-178f-a6dd-2b7d-3e1f3583e0fc",a("61654c1e-178f-a6dd-2b7d-3e1f3583e0fc"),1.986516);export{f as a};
