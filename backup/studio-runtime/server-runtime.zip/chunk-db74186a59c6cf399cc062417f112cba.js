import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as r}from"./chunk-af4a0f353769a78e174f04db2f366209.js";import{c as a}from"./chunk-455e93148f25cfd617316d4873aa2468.js";var c=r("pink-bob","c3cc1e3f-dc74-6250-26a3-a1fb6d26fb07",a("c3cc1e3f-dc74-6250-26a3-a1fb6d26fb07"),2.001625);export{c as a};
