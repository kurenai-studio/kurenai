import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as o}from"./chunk-0940ce6504f8be94bdd18ac0f4d5e763.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";export{o as Style};
