import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
function x(o){let s=0,n=0;for(let t of o)s+=t.w*t.h,n=Math.max(n,t.w);o.sort((t,a)=>a.h-t.h);let e=[{x:0,y:0,w:Math.max(Math.ceil(Math.sqrt(s/.95)),n),h:1/0}],w=0,i=0;for(let t of o)for(let a=e.length-1;a>=0;a--){let h=e[a];if(!(t.w>h.w||t.h>h.h)){if(t.x=h.x,t.y=h.y,i=Math.max(i,t.y+t.h),w=Math.max(w,t.x+t.w),t.w===h.w&&t.h===h.h){let l=e.pop();a<e.length&&(e[a]=l)}else t.h===h.h?(h.x+=t.w,h.w-=t.w):t.w===h.w?(h.y+=t.h,h.h-=t.h):(e.push({x:h.x+t.w,y:h.y,w:h.w-t.w,h:t.h}),h.y+=t.h,h.h-=t.h);break}}return{w,h:i,fill:s/(w*i)||0}}export{x as a};
/*! Bundled license information:

three/examples/jsm/libs/potpack.module.js:
  (**
   * potpack - by [@mourner](https://github.com/mourner)
   * 
   * A tiny JavaScript function for packing 2D rectangles into a near-square container, 
   * which is useful for generating CSS sprites and WebGL textures. Similar to 
   * [shelf-pack](https://github.com/mapbox/shelf-pack), but static (you can't add items 
   * once a layout is generated), and aims for maximal space utilization.
   *
   * A variation of algorithms used in [rectpack2D](https://github.com/TeamHypersomnia/rectpack2D)
   * and [bin-pack](https://github.com/bryanburgers/bin-pack), which are in turn based 
   * on [this article by Blackpawn](http://blackpawn.com/texts/lightmaps/default.html).
   * 
   * @license
   * ISC License
   * 
   * Copyright (c) 2018, Mapbox
   * 
   * Permission to use, copy, modify, and/or distribute this software for any purpose
   * with or without fee is hereby granted, provided that the above copyright notice
   * and this permission notice appear in all copies.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
   * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
   * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
   * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
   * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
   * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
   * THIS SOFTWARE.
   *)
*/
