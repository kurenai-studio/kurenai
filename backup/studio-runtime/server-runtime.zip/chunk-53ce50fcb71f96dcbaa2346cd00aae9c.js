import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var i=new WeakMap;function n(e,o){i.set(e,o)}function t(e){let o=i.get(e);if(o)return{clips:o.clips,release:o.claimRootInference()}}export{n as a,t as b};
