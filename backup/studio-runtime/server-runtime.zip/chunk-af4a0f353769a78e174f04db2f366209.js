import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
var o={idle:"idle",walk:"run",run:"run",sprint:"sprint",jump:"jump_idle",fall:"fall"},s={x:0,y:0,z:0};function n(a,e,t,r){return{id:a,assetId:e,assetUrl:t,rotationDegrees:s,scale:r,clipNames:o}}export{n as a};
