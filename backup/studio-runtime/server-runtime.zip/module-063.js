import { createRequire as __wanakaCreateRequire } from 'node:module'; const require = __wanakaCreateRequire(import.meta.url);
import{a as o}from"./chunk-983c6782bbff1eab728b30087fe20abe.js";import"./chunk-266dd0f2f8e0093a40d25f28f00505f3.js";import"./chunk-e2afe90afb807d84f9ee8f5730ad85f1.js";import"./chunk-d72ba78694eb01a5b80dc3858e530adc.js";export{o as LoftGeometry};
